package com.pinsta.app.models;

public class StoryModel {
    private String name;
    private String initials;
    private int avatarResId;
    private int bgColor;
    private int fgColor;
    private boolean isSeen;
    private boolean isAddStory;

    public StoryModel(String name, String initials, int avatarResId,
                      int bgColor, int fgColor, boolean isSeen) {
        this.name = name;
        this.initials = initials;
        this.avatarResId = avatarResId;
        this.bgColor = bgColor;
        this.fgColor = fgColor;
        this.isSeen = isSeen;
        this.isAddStory = false;
    }

    // Factory for "Add Story" item
    public static StoryModel createAddStory() {
        StoryModel s = new StoryModel("Add Story", "+", -1, 0, 0, false);
        s.isAddStory = true;
        return s;
    }

    public String getName() { return name; }
    public String getInitials() { return initials; }
    public int getAvatarResId() { return avatarResId; }
    public int getBgColor() { return bgColor; }
    public int getFgColor() { return fgColor; }
    public boolean isSeen() { return isSeen; }
    public boolean isAddStory() { return isAddStory; }
    public void setSeen(boolean seen) { isSeen = seen; }
}
