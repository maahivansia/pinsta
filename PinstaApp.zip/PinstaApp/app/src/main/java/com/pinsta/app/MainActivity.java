package com.pinsta.app;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.pinsta.app.adapters.PinAdapter;
import com.pinsta.app.adapters.StoryAdapter;
import com.pinsta.app.models.PinModel;
import com.pinsta.app.models.StoryModel;
import com.pinsta.app.utils.DataProvider;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView storiesRecycler;
    private RecyclerView pinsRecycler;
    private PinAdapter pinAdapter;
    private StoryAdapter storyAdapter;
    private List<PinModel> allPins;
    private List<PinModel> displayedPins;
    private ChipGroup categoryChipGroup;
    private BottomNavigationView bottomNav;
    private LinearLayout homeContent, exploreContent, savedContent, profileContent;
    private EditText searchInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupStories();
        setupPins();
        setupCategories();
        setupBottomNav();
        setupSearch();
    }

    private void initViews() {
        storiesRecycler = findViewById(R.id.stories_recycler);
        pinsRecycler    = findViewById(R.id.pins_recycler);
        categoryChipGroup = findViewById(R.id.category_chips);
        bottomNav       = findViewById(R.id.bottom_nav);
        searchInput     = findViewById(R.id.search_input);
        homeContent     = findViewById(R.id.home_content);
        exploreContent  = findViewById(R.id.explore_content);
        savedContent    = findViewById(R.id.saved_content);
        profileContent  = findViewById(R.id.profile_content);
    }

    private void setupStories() {
        List<StoryModel> stories = DataProvider.getStories();
        storyAdapter = new StoryAdapter(this, stories, story -> {
            if (!story.isAddStory()) story.setSeen(true);
            storyAdapter.notifyDataSetChanged();
        });
        storiesRecycler.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        storiesRecycler.setAdapter(storyAdapter);
    }

    private void setupPins() {
        allPins = DataProvider.getPins();
        displayedPins = new ArrayList<>(allPins);

        pinAdapter = new PinAdapter(this, displayedPins, pin -> {
            // Open detail
            android.content.Intent intent = new android.content.Intent(this, PinDetailActivity.class);
            intent.putExtra("pin_id", pin.getId());
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });

        StaggeredGridLayoutManager gridManager =
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        gridManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        pinsRecycler.setLayoutManager(gridManager);
        pinsRecycler.setAdapter(pinAdapter);
        pinsRecycler.setHasFixedSize(false);
    }

    private void setupCategories() {
        String[] cats = DataProvider.getCategories();
        for (int i = 0; i < cats.length; i++) {
            Chip chip = new Chip(this);
            chip.setText(cats[i]);
            chip.setCheckable(true);
            chip.setCheckedIconVisible(false);
            chip.setChipBackgroundColorResource(R.color.chip_bg_selector);
            chip.setTextColor(getResources().getColorStateList(R.color.chip_text_selector, null));
            chip.setChipStrokeColorResource(R.color.chip_stroke_selector);
            chip.setChipStrokeWidth(1f);
            int finalI = i;
            chip.setOnClickListener(v -> filterByCategory(cats[finalI]));
            if (i == 0) chip.setChecked(true);
            categoryChipGroup.addView(chip);
        }
    }

    private void filterByCategory(String category) {
        displayedPins.clear();
        if (category.equals("All")) {
            displayedPins.addAll(allPins);
        } else {
            for (PinModel p : allPins) {
                if (p.getCategory().equalsIgnoreCase(category)) displayedPins.add(p);
            }
        }
        pinAdapter.notifyDataSetChanged();
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            homeContent.setVisibility(id == R.id.nav_home ? View.VISIBLE : View.GONE);
            exploreContent.setVisibility(id == R.id.nav_explore ? View.VISIBLE : View.GONE);
            savedContent.setVisibility(id == R.id.nav_saved ? View.VISIBLE : View.GONE);
            profileContent.setVisibility(id == R.id.nav_profile ? View.VISIBLE : View.GONE);
            if (id == R.id.nav_create) {
                startActivity(new android.content.Intent(this, CreatePinActivity.class));
                return false;
            }
            return true;
        });
    }

    private void setupSearch() {
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                String q = s.toString().toLowerCase().trim();
                displayedPins.clear();
                if (q.isEmpty()) {
                    displayedPins.addAll(allPins);
                } else {
                    for (PinModel p : allPins) {
                        if (p.getTitle().toLowerCase().contains(q) ||
                            p.getCategory().toLowerCase().contains(q) ||
                            p.getAuthorName().toLowerCase().contains(q)) {
                            displayedPins.add(p);
                        }
                    }
                }
                pinAdapter.notifyDataSetChanged();
            }
            public void afterTextChanged(android.text.Editable e) {}
        });
    }
}
