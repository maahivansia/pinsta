package com.pinsta.app;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.pinsta.app.models.PinModel;
import com.pinsta.app.utils.DataProvider;
import java.util.List;

public class PinDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_detail);

        int pinId = getIntent().getIntExtra("pin_id", 1);
        List<PinModel> pins = DataProvider.getPins();
        PinModel pin = null;
        for (PinModel p : pins) { if (p.getId() == pinId) { pin = p; break; } }
        if (pin == null) { finish(); return; }

        ImageView image = findViewById(R.id.detail_image);
        TextView title = findViewById(R.id.detail_title);
        TextView category = findViewById(R.id.detail_category);
        TextView description = findViewById(R.id.detail_description);
        TextView authorInitials = findViewById(R.id.detail_author_initials);
        View authorBg = findViewById(R.id.detail_author_bg);
        TextView authorName = findViewById(R.id.detail_author_name);
        TextView likeCount = findViewById(R.id.detail_like_count);
        ImageButton likeBtn = findViewById(R.id.detail_like_btn);
        ImageButton saveBtn = findViewById(R.id.detail_save_btn);
        ImageButton backBtn = findViewById(R.id.detail_back_btn);
        ImageButton shareBtn = findViewById(R.id.detail_share_btn);

        image.setImageResource(pin.getImageResId());
        title.setText(pin.getTitle());
        category.setText(pin.getCategory());
        description.setText(pin.getDescription().isEmpty()
                ? "A beautiful capture that tells a story." : pin.getDescription());
        authorInitials.setText(pin.getAuthorInitials());
        authorInitials.setTextColor(pin.getAvatarFgColor());
        authorBg.setBackgroundColor(pin.getAvatarBgColor());
        authorName.setText(pin.getAuthorName());
        likeCount.setText(pin.getFormattedLikes() + " likes");

        updateLike(likeBtn, likeCount, pin);
        updateSave(saveBtn, pin);

        PinModel finalPin = pin;
        likeBtn.setOnClickListener(v -> {
            finalPin.setLiked(!finalPin.isLiked());
            updateLike(likeBtn, likeCount, finalPin);
        });
        saveBtn.setOnClickListener(v -> {
            finalPin.setSaved(!finalPin.isSaved());
            updateSave(saveBtn, finalPin);
            Toast.makeText(this, finalPin.isSaved() ? "Saved to board!" : "Removed from saved",
                    Toast.LENGTH_SHORT).show();
        });
        shareBtn.setOnClickListener(v -> {
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(android.content.Intent.EXTRA_TEXT,
                    "Check out \"" + finalPin.getTitle() + "\" on Pinsta!");
            startActivity(android.content.Intent.createChooser(share, "Share via"));
        });
        backBtn.setOnClickListener(v -> { finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); });
    }

    private void updateLike(ImageButton btn, TextView count, PinModel pin) {
        if (pin.isLiked()) {
            btn.setImageResource(R.drawable.ic_favorite);
            btn.setColorFilter(getResources().getColor(R.color.accent, null));
        } else {
            btn.setImageResource(R.drawable.ic_favorite_border);
            btn.setColorFilter(getResources().getColor(R.color.text_secondary, null));
        }
        count.setText(pin.getFormattedLikes() + " likes");
    }

    private void updateSave(ImageButton btn, PinModel pin) {
        if (pin.isSaved()) {
            btn.setImageResource(R.drawable.ic_bookmark);
            btn.setColorFilter(getResources().getColor(R.color.accent, null));
        } else {
            btn.setImageResource(R.drawable.ic_bookmark_border);
            btn.setColorFilter(getResources().getColor(R.color.text_secondary, null));
        }
    }
}
