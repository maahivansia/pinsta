package com.pinsta.app;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class CreatePinActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_pin);

        ImageButton back = findViewById(R.id.create_back_btn);
        Button publish = findViewById(R.id.publish_btn);
        if (back != null) back.setOnClickListener(v -> finish());
        if (publish != null) publish.setOnClickListener(v -> {
            Toast.makeText(this, "Pin published!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
