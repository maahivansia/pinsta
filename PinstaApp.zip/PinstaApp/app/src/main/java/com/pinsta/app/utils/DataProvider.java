package com.pinsta.app.utils;

import android.graphics.Color;
import com.pinsta.app.R;
import com.pinsta.app.models.PinModel;
import com.pinsta.app.models.StoryModel;
import java.util.ArrayList;
import java.util.List;

public class DataProvider {

    public static List<PinModel> getPins() {
        List<PinModel> pins = new ArrayList<>();
        pins.add(new PinModel(1, "Golden hour in Santorini", "Travel",
                "Alex Lee", "AL", R.drawable.pin_01, R.drawable.avatar_01,
                Color.parseColor("#FFF0F2"), Color.parseColor("#E8445A"), 2841, "2h ago"));
        pins.get(0).setDescription("Watching the sun dip below the caldera — pure magic. Santorini never disappoints with those iconic blue domes and warm amber skies.");

        pins.add(new PinModel(2, "Minimalist living room with warm tones", "Interior",
                "Maya R.", "MR", R.drawable.pin_02, R.drawable.avatar_02,
                Color.parseColor("#E1F5EE"), Color.parseColor("#0F6E56"), 1204, "4h ago"));
        pins.get(1).setDescription("Less is more. Natural linen, warm oak, and a single trailing plant — everything you need for a peaceful home.");

        pins.add(new PinModel(3, "Matcha latte art at sunrise", "Food & Drink",
                "Kai P.", "KP", R.drawable.pin_03, R.drawable.avatar_03,
                Color.parseColor("#E6F1FB"), Color.parseColor("#185FA5"), 987, "5h ago"));
        pins.get(2).setDescription("Ceremonial grade matcha, oat milk foam, and a slow morning. The perfect ritual to start any day.");

        pins.add(new PinModel(4, "Autumn street style lookbook", "Fashion",
                "Sofia R.", "SR", R.drawable.pin_04, R.drawable.avatar_04,
                Color.parseColor("#FBEAF0"), Color.parseColor("#993356"), 3320, "6h ago"));
        pins.get(3).setDescription("Earthy tones, oversized blazers, and chunky boots — autumn dressing at its finest.");

        pins.add(new PinModel(5, "Brutalist concrete architecture, Tokyo", "Architecture",
                "Tom M.", "TM", R.drawable.pin_05, R.drawable.avatar_05,
                Color.parseColor("#FAEEDA"), Color.parseColor("#854F0B"), 756, "8h ago"));
        pins.get(4).setDescription("Tokyo's hidden brutalist gems tell a story of 1970s ambition. Raw concrete, bold geometry, timeless design.");

        pins.add(new PinModel(6, "Sunset surf session, golden coast", "Lifestyle",
                "Priya N.", "PN", R.drawable.pin_06, R.drawable.avatar_06,
                Color.parseColor("#EAF3DE"), Color.parseColor("#3B6D11"), 4112, "10h ago"));
        pins.get(5).setDescription("Chasing the last light with nothing but a board and the ocean. Some days are just perfect.");

        pins.add(new PinModel(7, "Handmade ceramic mugs from the kiln", "DIY & Crafts",
                "Alex Lee", "AL", R.drawable.pin_07, R.drawable.avatar_01,
                Color.parseColor("#FFF0F2"), Color.parseColor("#E8445A"), 623, "12h ago"));
        pins.get(6).setDescription("Six hours at the wheel, two firings, and these beauties emerged. Each one perfectly imperfect.");

        pins.add(new PinModel(8, "Hiking in Patagonia, end of winter", "Adventure",
                "Maya R.", "MR", R.drawable.pin_08, R.drawable.avatar_02,
                Color.parseColor("#E1F5EE"), Color.parseColor("#0F6E56"), 2100, "1d ago"));
        pins.get(7).setDescription("Torres del Paine in shoulder season — fewer crowds, dramatic skies, and trails that feel like another planet.");

        pins.add(new PinModel(9, "Abstract oil painting — process reel", "Art",
                "Sofia R.", "SR", R.drawable.pin_09, R.drawable.avatar_04,
                Color.parseColor("#FBEAF0"), Color.parseColor("#993356"), 1456, "1d ago"));
        pins.get(8).setDescription("Palette knives, bold strokes, and happy accidents. The process is always the best part.");

        pins.add(new PinModel(10, "Tokyo neon nights, slow shutter", "Photography",
                "Dev W.", "DW", R.drawable.pin_10, R.drawable.avatar_07,
                Color.parseColor("#EEEDFE"), Color.parseColor("#533AB7"), 5230, "2d ago"));
        pins.get(9).setDescription("1/4 second shutter, tripod, and patience. Shinjuku at midnight has a light show that never repeats.");

        pins.add(new PinModel(11, "Linen and sage — spring wardrobe capsule", "Fashion",
                "Priya N.", "PN", R.drawable.pin_11, R.drawable.avatar_06,
                Color.parseColor("#EAF3DE"), Color.parseColor("#3B6D11"), 892, "2d ago"));
        pins.get(10).setDescription("10 pieces, 30 outfits, zero waste. Building a wardrobe that actually works.");

        pins.add(new PinModel(12, "Birria tacos with rich consommé", "Food & Drink",
                "Tom M.", "TM", R.drawable.pin_12, R.drawable.avatar_05,
                Color.parseColor("#FAEEDA"), Color.parseColor("#854F0B"), 1780, "3d ago"));
        pins.get(11).setDescription("Slow-braised beef cheek, corn tortillas, melted Oaxacan cheese. Dipped twice. Worth every hour.");

        return pins;
    }

    public static List<StoryModel> getStories() {
        List<StoryModel> stories = new ArrayList<>();
        stories.add(StoryModel.createAddStory());
        stories.add(new StoryModel("Alex", "AL", R.drawable.avatar_01,
                Color.parseColor("#FFF0F2"), Color.parseColor("#E8445A"), false));
        stories.add(new StoryModel("Maya", "MR", R.drawable.avatar_02,
                Color.parseColor("#E1F5EE"), Color.parseColor("#0F6E56"), false));
        stories.add(new StoryModel("Kai", "KP", R.drawable.avatar_03,
                Color.parseColor("#E6F1FB"), Color.parseColor("#185FA5"), false));
        stories.add(new StoryModel("Sofia", "SR", R.drawable.avatar_04,
                Color.parseColor("#FBEAF0"), Color.parseColor("#993356"), true));
        stories.add(new StoryModel("Tom", "TM", R.drawable.avatar_05,
                Color.parseColor("#FAEEDA"), Color.parseColor("#854F0B"), true));
        stories.add(new StoryModel("Priya", "PN", R.drawable.avatar_06,
                Color.parseColor("#EAF3DE"), Color.parseColor("#3B6D11"), true));
        stories.add(new StoryModel("Dev", "DW", R.drawable.avatar_07,
                Color.parseColor("#EEEDFE"), Color.parseColor("#533AB7"), true));
        return stories;
    }

    public static String[] getCategories() {
        return new String[]{"All", "Photography", "Travel", "Fashion",
                "Food & Drink", "Architecture", "Art", "Fitness", "DIY & Crafts", "Minimal", "Nature"};
    }
}
