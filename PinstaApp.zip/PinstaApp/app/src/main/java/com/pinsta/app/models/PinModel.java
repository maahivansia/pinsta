package com.pinsta.app.models;

public class PinModel {
    private int id;
    private String title;
    private String category;
    private String authorName;
    private String authorInitials;
    private int imageResId;
    private int avatarResId;
    private int avatarBgColor;
    private int avatarFgColor;
    private int likeCount;
    private boolean isLiked;
    private boolean isSaved;
    private String timeAgo;
    private String description;

    public PinModel(int id, String title, String category, String authorName,
                    String authorInitials, int imageResId, int avatarResId,
                    int avatarBgColor, int avatarFgColor, int likeCount, String timeAgo) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.authorName = authorName;
        this.authorInitials = authorInitials;
        this.imageResId = imageResId;
        this.avatarResId = avatarResId;
        this.avatarBgColor = avatarBgColor;
        this.avatarFgColor = avatarFgColor;
        this.likeCount = likeCount;
        this.timeAgo = timeAgo;
        this.isLiked = false;
        this.isSaved = false;
        this.description = "";
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getAuthorName() { return authorName; }
    public String getAuthorInitials() { return authorInitials; }
    public int getImageResId() { return imageResId; }
    public int getAvatarResId() { return avatarResId; }
    public int getAvatarBgColor() { return avatarBgColor; }
    public int getAvatarFgColor() { return avatarFgColor; }
    public int getLikeCount() { return likeCount; }
    public boolean isLiked() { return isLiked; }
    public boolean isSaved() { return isSaved; }
    public String getTimeAgo() { return timeAgo; }
    public String getDescription() { return description; }

    public void setLiked(boolean liked) {
        if (liked && !isLiked) likeCount++;
        else if (!liked && isLiked) likeCount--;
        isLiked = liked;
    }
    public void setSaved(boolean saved) { isSaved = saved; }
    public void setDescription(String description) { this.description = description; }

    public String getFormattedLikes() {
        if (likeCount >= 1000) return String.format("%.1fk", likeCount / 1000.0);
        return String.valueOf(likeCount);
    }
}
