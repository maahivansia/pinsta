package com.pinsta.app.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.pinsta.app.R;
import com.pinsta.app.models.StoryModel;
import java.util.List;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {

    public interface OnStoryClickListener { void onStoryClick(StoryModel story); }

    private final Context context;
    private final List<StoryModel> stories;
    private final OnStoryClickListener listener;

    public StoryAdapter(Context ctx, List<StoryModel> stories, OnStoryClickListener listener) {
        this.context = ctx;
        this.stories = stories;
        this.listener = listener;
    }

    @NonNull @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_story, parent, false);
        return new StoryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder h, int position) {
        StoryModel story = stories.get(position);

        if (story.isAddStory()) {
            h.storyRing.setBackgroundResource(R.drawable.bg_story_add);
            h.avatarBg.setBackgroundColor(
                    context.getResources().getColor(R.color.bg, null));
            h.initials.setText("+");
            h.initials.setTextColor(
                    context.getResources().getColor(R.color.accent, null));
            h.initials.setTextSize(24f);
        } else {
            h.storyRing.setBackgroundResource(story.isSeen()
                    ? R.drawable.bg_story_seen : R.drawable.bg_story_unseen);
            h.avatarBg.setBackgroundColor(story.getBgColor());
            h.initials.setText(story.getInitials());
            h.initials.setTextColor(story.getFgColor());
            h.initials.setTextSize(15f);
        }
        h.name.setText(story.getName());

        h.itemView.setOnClickListener(v -> {
            listener.onStoryClick(story);
            if (!story.isAddStory()) {
                Toast.makeText(context, story.getName() + "'s story", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override public int getItemCount() { return stories.size(); }

    static class StoryViewHolder extends RecyclerView.ViewHolder {
        View storyRing, avatarBg;
        TextView initials, name;

        StoryViewHolder(View v) {
            super(v);
            storyRing = v.findViewById(R.id.story_ring);
            avatarBg  = v.findViewById(R.id.story_avatar_bg);
            initials  = v.findViewById(R.id.story_initials);
            name      = v.findViewById(R.id.story_name);
        }
    }
}
