package com.pinsta.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.pinsta.app.R;
import com.pinsta.app.models.PinModel;
import java.util.List;

public class PinAdapter extends RecyclerView.Adapter<PinAdapter.PinViewHolder> {

    public interface OnPinClickListener { void onPinClick(PinModel pin); }

    private final Context context;
    private final List<PinModel> pins;
    private final OnPinClickListener listener;

    public PinAdapter(Context context, List<PinModel> pins, OnPinClickListener listener) {
        this.context = context;
        this.pins = pins;
        this.listener = listener;
    }

    @NonNull @Override
    public PinViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_pin, parent, false);
        return new PinViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PinViewHolder h, int position) {
        PinModel pin = pins.get(position);

        h.pinImage.setImageResource(pin.getImageResId());
        h.pinTitle.setText(pin.getTitle());
        h.pinCategory.setText(pin.getCategory());
        h.authorAvatar.setBackgroundColor(pin.getAvatarBgColor());
        h.authorInitials.setText(pin.getAuthorInitials());
        h.authorInitials.setTextColor(pin.getAvatarFgColor());
        h.authorName.setText(pin.getAuthorName());
        h.likeCount.setText(pin.getFormattedLikes());
        h.timeAgo.setText(pin.getTimeAgo());

        updateLikeBtn(h, pin);
        updateSaveBtn(h, pin);

        h.likeBtn.setOnClickListener(v -> {
            pin.setLiked(!pin.isLiked());
            h.likeCount.setText(pin.getFormattedLikes());
            updateLikeBtn(h, pin);
        });

        h.saveBtn.setOnClickListener(v -> {
            pin.setSaved(!pin.isSaved());
            updateSaveBtn(h, pin);
        });

        h.card.setOnClickListener(v -> listener.onPinClick(pin));

        // Stagger entrance animation
        h.card.setAlpha(0f);
        h.card.animate().alpha(1f).setDuration(300).setStartDelay(position * 40L).start();
    }

    private void updateLikeBtn(PinViewHolder h, PinModel pin) {
        if (pin.isLiked()) {
            h.likeBtn.setImageResource(R.drawable.ic_favorite);
            h.likeBtn.setColorFilter(context.getResources().getColor(R.color.accent, null));
            h.likeCount.setTextColor(context.getResources().getColor(R.color.accent, null));
        } else {
            h.likeBtn.setImageResource(R.drawable.ic_favorite_border);
            h.likeBtn.setColorFilter(context.getResources().getColor(R.color.text_secondary, null));
            h.likeCount.setTextColor(context.getResources().getColor(R.color.text_secondary, null));
        }
    }

    private void updateSaveBtn(PinViewHolder h, PinModel pin) {
        if (pin.isSaved()) {
            h.saveBtn.setImageResource(R.drawable.ic_bookmark);
            h.saveBtn.setColorFilter(context.getResources().getColor(R.color.accent, null));
            h.saveBtn.setBackgroundResource(R.drawable.bg_save_active);
        } else {
            h.saveBtn.setImageResource(R.drawable.ic_bookmark_border);
            h.saveBtn.setColorFilter(context.getResources().getColor(R.color.text_secondary, null));
            h.saveBtn.setBackgroundResource(R.drawable.bg_save_default);
        }
    }

    @Override public int getItemCount() { return pins.size(); }

    static class PinViewHolder extends RecyclerView.ViewHolder {
        CardView card;
        ImageView pinImage;
        TextView pinTitle, pinCategory, authorInitials, authorName, likeCount, timeAgo;
        View authorAvatar;
        ImageButton likeBtn, saveBtn;

        PinViewHolder(View v) {
            super(v);
            card = v.findViewById(R.id.pin_card);
            pinImage = v.findViewById(R.id.pin_image);
            pinTitle = v.findViewById(R.id.pin_title);
            pinCategory = v.findViewById(R.id.pin_category);
            authorAvatar = v.findViewById(R.id.author_avatar);
            authorInitials = v.findViewById(R.id.author_initials);
            authorName = v.findViewById(R.id.author_name);
            likeCount = v.findViewById(R.id.like_count);
            likeBtn = v.findViewById(R.id.like_btn);
            saveBtn = v.findViewById(R.id.save_btn);
            timeAgo = v.findViewById(R.id.time_ago);
        }
    }
}
